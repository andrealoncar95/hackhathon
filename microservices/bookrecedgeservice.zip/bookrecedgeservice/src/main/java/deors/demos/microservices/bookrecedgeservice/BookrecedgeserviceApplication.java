package deors.demos.microservices.bookrecedgeservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BookrecedgeserviceApplication {

	public static void main(String[] args) {
		SpringApplication.run(BookrecedgeserviceApplication.class, args);
	}
}
